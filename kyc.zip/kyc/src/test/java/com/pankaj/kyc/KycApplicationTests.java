package com.pankaj.kyc;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class KycApplicationTests {

	@Test
	void contextLoads() {
	}

}
